"""Specifies the version of the yopo package."""

__title__ = "yopo"
__author__ = "Adarsh Chekodu"
__description__ = "You Only Plot Once"
__url__ = ""
__version__ = "0.0.1"
__holo_version__ = "0.0.1"
__license__ = "Apache License 2.0"