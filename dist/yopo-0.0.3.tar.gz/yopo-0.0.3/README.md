# YOPO

**You Only Plot Once**

YOPO lets you plot various graphs and charts with a click of a button. This tool uses Dash and Flask in backend

# :warning: Work in Progress